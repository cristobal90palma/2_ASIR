<?php
include_once "funcionesLogin.php";
session_start();

cerrarSesion();

?>