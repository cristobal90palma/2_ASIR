<?php

$server = "localhost";
$user = "root";
$passwd = "Usuario.25";
$db = "iawFinal";


?>