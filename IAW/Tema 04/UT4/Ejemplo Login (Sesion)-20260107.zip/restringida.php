<?php
    session_start();
    if ($_SESSION["nombre"]!=null and $_SESSION["error"]==null){
        echo "Bienvenido. Está usted dentro de una página privada.<br>";
        echo "<p><a href='cerrar.php'>Cerrar sesión</a></p>";
    } else {
        header("Location: login.php");
    }
?>