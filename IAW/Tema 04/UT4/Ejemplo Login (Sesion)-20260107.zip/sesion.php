<?php

    $nombre = $_POST["nombre"];
    $pass = $_POST["pass"];
    $nombre_ok = "admin";
    $pass_ok = "123456";

    session_start();
    
    if ($nombre!=null and $pass!=null and $nombre==$nombre_ok and $pass==$pass_ok){
        $_SESSION["error"] = null;
        $_SESSION["nombre"] = $nombre;
        //header("Location: restringida.php"); 
        echo "<p><a href='restringida.php'>Acceso a página restringida</a></p>";
    } elseif ($_SESSION["nombre"]!=null and $_SESSION["nombre"]!=""){
        $_SESSION["error"] = null;
        $_SESSION["nombre"] = $nombre;
        //header("Location: restringida.php"); 
        echo "<p><a href='restringida.php'>Acceso a página restringida</a></p>"; 
    } else {
        $_SESSION["error"] = "Debe introducir los datos correctamente";
        $_SESSION["nombre"] = null;
        //header("Location: login.php");
        echo "<p style='color: red;'>$_SESSION[error]</p>"; 
        echo "<p><a href='login.php'>Acceso a login</a></p>";
    }

?>